daily_stock_prices = [1000, 900, 1700, 2100, 4000,3900,2350]

max_value = max(daily_stock_prices)
min_value = min(daily_stock_prices,)

print(max_value) # to print the maximum value of daily stock prices 
print(min_value) # to print the minimum value of daily stock prices
