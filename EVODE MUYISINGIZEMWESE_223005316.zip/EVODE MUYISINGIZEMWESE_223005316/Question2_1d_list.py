
myShoppingList = ["Shoes", "Trousers", "shorts", "pullovers"]
myShoppingList.remove("Trousers")

print(myShoppingList)
