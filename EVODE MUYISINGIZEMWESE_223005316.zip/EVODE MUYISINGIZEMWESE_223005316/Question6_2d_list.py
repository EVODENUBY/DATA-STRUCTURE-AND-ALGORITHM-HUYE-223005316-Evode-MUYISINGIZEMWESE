student = [
    ["vital", 13, 85],
    ["evode", 15, 90],
    ["ange", 17, 89]
]
studentSortedByGrade =sorted(student, key=lambda x: x[2])

print(studentSortedByGrade)