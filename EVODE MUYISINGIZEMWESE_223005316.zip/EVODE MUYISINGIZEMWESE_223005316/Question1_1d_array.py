temp_readings = [23, 21, 20, 30, 19,19.5, 24]
print(temp_readings)