# Initialize a 2D array for sales (products x days)
# Rows: Products, Columns: Days (Monday to Sunday)
sales = [
    [150, 200, 250, 300, 180, 220, 190],  # Product 1 sales for the week
    [100, 120, 90, 110, 95, 130, 80],     # Product 2 sales for the week
    [300, 340, 290, 310, 320, 330, 310],  # Product 3 sales for the week
]

# Days of the week for display
days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

# Display the sales data
print("Weekly Sales of Products:")
for i, product_sales in enumerate(sales):
    print(f"\tProduct {i+1} sales:")
    for j, sale in enumerate(product_sales):
        print(f"{days[j]}: {sale}")
