# Create a 3x3 tic-tac-toe board
board = [
    ['X', 'O', 'X'],
    ['O', 'X', 'O'],
    ['O', '_', 'X']
]

# Function to check for a winner
def check_winner(board):
    # Check rows and columns
    for i in range(3):
        if board[i][0] == board[i][1] == board[i][2] and board[i][0] != '_':
            return f"Winner is {board[i][0]}"
        if board[0][i] == board[1][i] == board[2][i] and board[0][i] != '_':
            return f"Winner is {board[0][i]}"
    
    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != '_':
        return f"Winner is {board[0][0]}"
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != '_':
        return f"Winner is {board[0][2]}"
    
    return "No winner"
 #Check and print the result
print(check_winner(board))
