student_marks = [97, 80, 65, 70]
student_marks.reverse() #to reverse the order of student marks

print(student_marks) 
