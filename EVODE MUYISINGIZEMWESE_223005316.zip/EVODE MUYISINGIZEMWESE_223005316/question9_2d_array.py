# Define the 2D array for student marks in different subjects
# Each row represents a student, each column represents a subject

marks = [
    [75, 80, 85],  # Marks for Student 1 in 3 subjects
    [65, 70, 75],  # Marks for Student 2 in 3 subjects
    [90, 85, 95]   # Marks for Student 3 in 3 subjects
]

# Initialize an empty list to store total marks for each student
total_marks = []

# Loop through each student's marks
for student_marks in marks:
    # Calculate the total marks for each student by summing up their marks
    total = sum(student_marks)
    total_marks.append(total)

# Display the total marks for each student
for i, total in enumerate(total_marks, start=1):
    print(f"Total marks for Student {i}: {total}")
