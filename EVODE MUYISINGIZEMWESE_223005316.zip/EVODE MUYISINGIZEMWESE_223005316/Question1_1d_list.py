meetingAttendeeList = ["evode", "nuby", "patrick","emmy"]

meetingAttendeeList.append("pascal")
print(meetingAttendeeList)
