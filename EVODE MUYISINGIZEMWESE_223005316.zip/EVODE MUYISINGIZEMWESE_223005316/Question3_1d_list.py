AgesList =[23, 34, 26, 12, 54,20]
AgesList.sort()

print(AgesList)