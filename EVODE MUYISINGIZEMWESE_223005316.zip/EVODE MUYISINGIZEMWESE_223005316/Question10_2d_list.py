# List of players and their scores in different games
# Each sublist contains: [player name, score in game 1, score in game 2, score in game 3]
scores = [
    ["Evode", 85, 90, 78],
    ["keza", 88, 22, 80],
    ["berry", 90, 40, 82],
    ["viky", 72, 95, 85],
    ["mimy", 60, 87, 90]
]

# Calculate the average score for each player
average_scores = [(player[0], sum(player[1:]) / len(player[1:])) for player in scores]

# Find the player with the highest average score
winner = max(average_scores, key=lambda x: x[1])

# Display the winner and their average score

print(f"The winner is {winner[0]} with an average score of {winner[1]:.2f}")









