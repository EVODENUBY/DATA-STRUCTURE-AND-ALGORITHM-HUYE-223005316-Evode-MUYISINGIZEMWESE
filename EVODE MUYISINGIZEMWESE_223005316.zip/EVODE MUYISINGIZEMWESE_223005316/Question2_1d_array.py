daily_sales = [10000, 3500, 4500, 700, 1000, 5000,6000]
average_of_daily_sales = sum(daily_sales) / len(daily_sales)
print(average_of_daily_sales) # average of daily sales
