
import random

# Generate a list of random numbers
random_numbers = [random.randint(1, 100) 
                  for _ in range(20)]  # List of 20 random numbers between 1 and 100

# Initialize counters for even and odd numbers
even_count = 0
odd_count = 0

# Count the even and odd numbers
for number in random_numbers:
    if number % 2 == 0:
        even_count += 1
    else:
        odd_count += 1

# Print the results

print("List of random numbers:", random_numbers)
print("Number of even numbers:", even_count)
print("Number of odd numbers:", odd_count)
