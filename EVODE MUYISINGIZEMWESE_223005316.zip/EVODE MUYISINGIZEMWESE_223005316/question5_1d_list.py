
friendList1 =["evode", "bernard", "adolphe", "vital"]
friendList2 =["wizzy", "jeremy","jimmy", "evode"]

mergedList =list(set(friendList1 + friendList2))

print(mergedList)
