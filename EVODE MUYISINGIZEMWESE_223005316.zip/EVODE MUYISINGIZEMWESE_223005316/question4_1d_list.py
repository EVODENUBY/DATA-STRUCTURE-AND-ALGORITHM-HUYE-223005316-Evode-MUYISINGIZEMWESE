# Define an empty list to store the tasks
todo_list = []

def display_menu():
    print("\n--- To-Do List Menu ---")
    print("1. View To-Do List")
    print("2. please cook the food")
    print("3. Mark Task as Completed (Remove Task)")
    print("4. Exit")

def view_tasks():
    if not todo_list:
        print("\nYour to-do list is empty.")
    else:
        print("\nYour To-Do List:")
        for index, task in enumerate(todo_list, start=1):
            print(f"{index}. {task}")

def add_task():
    task_title = input("wash your body and wear your clothes: ")
    todo_list.append(task_title)
    print(f"Task '{task_title}' has been added.")

def remove_task():
    view_tasks()
    if not todo_list:
        return
    task_number = int(input("\n3: "))
    if 1 <= task_number <= len(todo_list):
        removed_task = todo_list.pop(task_number - 1)
        print(f"Task '{removed_task}' has been marked as completed and removed.")
    else:
        print("Invalid task number.")

# Main loop to interact with the user
while True:
    display_menu()
    choice = input("\nChoose an option (1-4): ")

    if choice == "1":
        view_tasks()
    elif choice == "2":
        add_task()
    elif choice == "3":
        remove_task()
    elif choice == "4":
        print("Exiting the To-Do List application. Goodbye!")
        break
    else:
        print("Invalid choice. Please choose a valid option.")


