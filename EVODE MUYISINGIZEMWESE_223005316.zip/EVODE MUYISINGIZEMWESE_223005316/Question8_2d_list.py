# Create a 2D list representing the seating arrangement in a 5x5 theater
# 'O' means the seat is open, 'X' means the seat is reserved
seating_arrangement = [
    ['O', 'O', 'O', 'O', 'O'],  # Row 1
    ['O', 'O', 'O', 'O', 'O'],  # Row 2
    ['O', 'O', 'O', 'O', 'O'],  # Row 3
    ['O', 'O', 'O', 'O', 'O'],  # Row 4
    ['O', 'O', 'O', 'O', 'O']   # Row 5
]

# Assign reserved seats (mark as 'X')
reserved_seats = [(1, 2), (3, 4), (5, 1)]  # List of tuples (row, seat) for reserved seats

# Update the seating arrangement for reserved seats
for seat in reserved_seats:
    row, col = seat
    seating_arrangement[row - 1][col - 1] = 'X'  # Subtract 1 for zero-indexing

# Display the updated seating arrangement
for row in seating_arrangement:
    
    print(row)
