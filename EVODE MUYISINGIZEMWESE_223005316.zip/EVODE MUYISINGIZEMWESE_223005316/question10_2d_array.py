# Define the 3D array for daily temperature readings of 4 cities for a week
# Each sub-array represents a city, and contains daily temperature readings for a week (7 days)

temperatures = [
    [30, 32, 31, 29, 28, 30, 31],  # City 1
    [25, 26, 24, 23, 25, 26, 27],  # City 2
    [20, 21, 19, 22, 21, 20, 19],  # City 3
    [35, 36, 34, 33, 35, 34, 36]   # City 4
]

# Calculate and store the average temperature for each city
average_temperatures = []

for city in temperatures:
    # Calculate the average temperature by summing the temperatures and dividing by the number of days (7)
    avg_temp = sum(city) / len(city)
    average_temperatures.append(avg_temp)

# Display the average temperature for each city
for i, avg_temp in enumerate(average_temperatures, start=1):
    print(f"Average temperature for City {i}: {avg_temp:.2f}°C")
