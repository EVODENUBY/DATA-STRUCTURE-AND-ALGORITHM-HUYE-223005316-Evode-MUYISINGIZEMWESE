# 2D list where each sublist contains the monthly expenses for a category over 6 months
# Categories: Rent, Food, Utilities
expenses = [
    [1000, 900, 1700, 1300, 1230, 1260],  # Rent
    [400, 4700, 420, 430, 8000, 410],        # Food
    [150, 160, 155, 130, 165, 500]         # Utilities
]

# Calculate the average monthly expense per category
average_expenses = [sum(category) / len(category) for category in expenses]

# Display the average monthly expenses for each category

print("Average expenses per category:")
print(f"Rent: {average_expenses[0]:.2f}")
print(f"Food: {average_expenses[1]:.2f}")
print(f"Utilities: {average_expenses[2]:.2f}")
